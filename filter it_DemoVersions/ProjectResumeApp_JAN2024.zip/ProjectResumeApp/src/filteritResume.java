// Import the following packages:
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.DocumentFilter.FilterBypass;

/**
 * The following class is responsible for the building of the resumes
 * @author Sri
 *
 */
public class filteritResume implements KeyListener {
	
	// Class variables
	
	// For displayProjects() method
	public static JLabel projectStatus = new JLabel(); // updates the status of the project folder
	public static JLabel hello = new JLabel(); // to say hello to the user upon entry
	public static JButton addProject = new JButton(); // button to create new projects
	
	// For displayTemplates() method
	public static JButton formalTemplate = new JButton();
	public static JButton artTemplate = new JButton();
	public static JButton contempTemplate = new JButton();
	
	// For displayQuestions() method
	static String qFile = "questions.txt";
	static String aFile = "answers.txt";
	static String aeFile = "answersedit.txt";
	
	// For all resume template methods
	public static JLabel resume = new JLabel("your resume");
	public static JButton preview = new JButton("preview");
	
	// Create an instance variable that calls all the JTextAreas holding the user's
	// resume data using the displayTextAreas() method
	public static filteritResume area = new filteritResume();
	public static JTextArea p = new JTextArea(5, 20);
	public static JScrollPane jsp = new JScrollPane(p, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	
	/**
	 * The following is a constructor for the resume pages
	 */
	public filteritResume() {
		
		// Set the current design of the JFrame
		filteritApp.frame.setSize(500, 610);
		filteritApp.frame.getContentPane().setBackground(new Color(14, 22, 46));
		
	} // End of filteritResume() constructor
	
	/**
	 * The following method displays the current resume projects you are working on
	 */
	public static void displayProjects() {
		
		// Set the current design of the JFrame
		filteritApp.frame.setSize(500, 610);
		filteritApp.frame.getContentPane().setBackground(new Color(14, 22, 46));
		
		// Create a "your projects" header JLabel
		JLabel yourProjects = new JLabel("your projects");
		yourProjects.setBounds(120, 30, 280, 50);
		yourProjects.setFont(new Font("Ink Free", Font.BOLD, 40));
		yourProjects.setForeground(new Color(157, 170, 209));
		
		// Create a "current projects" sub-header JLabel
		JLabel currentProjects = new JLabel("current projects");
		currentProjects.setBounds(20, 100, 180, 30);
		currentProjects.setFont(new Font("Ink Free", Font.PLAIN, 25));
		currentProjects.setForeground(Color.WHITE);
		
		// Set the design of the project status JLabel
		projectStatus.setText("seems like you don't have any projects yet...");
		projectStatus.setBounds(60, 150, 380, 25);
		projectStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
		projectStatus.setForeground(new Color(250, 249, 246));
		
		// Set the design for the hello user JLabel
		hello.setText("hello " + filteritMenu.u);
		hello.setBounds(15, 12, 180, 25); 
		hello.setFont(new Font("Ink Free", Font.PLAIN, 17));
		hello.setForeground(Color.WHITE);
		
		// Add the JLabels to the frame
		filteritApp.frame.add(yourProjects);
		filteritApp.frame.add(currentProjects);
		filteritApp.frame.add(projectStatus);
		filteritApp.frame.add(hello);
		
		filteritApp.frame.setVisible(true);
		
		// Create a new project JButton
		addProject.setIcon(new ImageIcon("project.jpg"));
		addProject.setBounds(60, 200, 100, 130);
		addProject.setBackground(new Color(14, 22, 46));
		addProject.setBorder(BorderFactory.createEmptyBorder());
		
		// Add an ActionListener that leads the user to the templates page of the app
		addProject.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
				
				// Link to the templates page
				displayTemplates();
				
			}
			
		});
		
		// Add the new project JButton to the frame
		filteritApp.frame.add(addProject);
		
		// Add a "back" JButton that leads the user back to the login page
		JButton loginBack = new JButton("back");
		loginBack.setBounds(390, 520, 80, 35);
		loginBack.setBackground(new Color(135, 145, 161));
		loginBack.setFont(new Font("Ink Free", Font.BOLD, 20));
		
		// Add an ActionListener that leads the user back to the login page when the
		// button is clicked
		loginBack.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
				
				// Link to the login page
				filteritMenu.displayLogin();
				
			}
			
		});
		
		// Add the "back" JButton to the frame
		filteritApp.frame.add(loginBack);
	}
	
	/**
	 * The following method displays the available resume templates
	 */
	public static void displayTemplates() {
		
		// Set the current design of the JFrame
		filteritApp.frame.setSize(500, 670);
		filteritApp.frame.getContentPane().setBackground(new Color(14, 22, 46));
		
		// Create an "our designs" header JLabel
		JLabel ourDesigns = new JLabel("our designs");
		ourDesigns.setBounds(140, 30, 280, 50);
		ourDesigns.setFont(new Font("Ink Free", Font.BOLD, 40));
		ourDesigns.setForeground(new Color(157, 170, 209));
		
		// Add the JLabels to the frame
		filteritApp.frame.add(ourDesigns);
		
		// Create a formal template JButton
		formalTemplate.setIcon(new ImageIcon("formal.jpg"));
		formalTemplate.setBounds(30, 90, 170, 230);
		formalTemplate.setBackground(new Color(14, 22, 46));
		formalTemplate.setBorder(BorderFactory.createEmptyBorder());
		
		// Create an ActionListener that leads the user to edit the formal template
		formalTemplate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
				
				// Link to editing the formal template
				displayQuestions();
				
			}
			
			
		});
		
		// Create an artistic template JButton
		artTemplate.setIcon(new ImageIcon("art.jpg"));
		artTemplate.setBounds(280, 90, 170, 230);
		artTemplate.setBackground(new Color(14, 22, 46));
		artTemplate.setBorder(BorderFactory.createEmptyBorder());
		
		// Add an ActionListener that leads the user to edit the artistic template
		artTemplate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
				
				// Link to editing the artistic template
				
				
			}
			
		});
		
		// Create a contemporary template JButton
		contempTemplate.setIcon(new ImageIcon("contemporary.jpg"));
		contempTemplate.setBounds(150, 360, 170, 230);
		contempTemplate.setBackground(new Color(14, 22, 46));
		contempTemplate.setBorder(BorderFactory.createEmptyBorder());
		
		// Add an ActionListener that leads the user to edit the contemporary template
		contempTemplate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
				
				// Link to editing the contemporary template
				
				
			}
			
		});
		
		// Add the template JButtons to the frame
		filteritApp.frame.add(formalTemplate);
		filteritApp.frame.add(artTemplate);
		filteritApp.frame.add(contempTemplate);
		
		// Create the JLabels for the different templates
		JLabel formalDescrip = new JLabel("you're the next CEO");
		formalDescrip.setBounds(30, 325, 280, 25);
		formalDescrip.setFont(new Font("Ink Free", Font.PLAIN, 20));
		formalDescrip.setForeground(Color.WHITE);
		
		JLabel artDescrip = new JLabel("this generation's picasso");
		artDescrip.setBounds(257, 325, 280, 25);
		artDescrip.setFont(new Font("Ink Free", Font.PLAIN, 20));
		artDescrip.setForeground(Color.WHITE);
		
		JLabel contempDescrip = new JLabel("next google marketer?");
		contempDescrip.setBounds(140, 595, 350, 25);
		contempDescrip.setFont(new Font("Ink Free", Font.PLAIN, 20));
		contempDescrip.setForeground(Color.WHITE);
		
		// Add the template description JLabels to the frame
		filteritApp.frame.add(formalDescrip);
		filteritApp.frame.add(artDescrip);
		filteritApp.frame.add(contempDescrip);
		
		// Add a "back" JButton that leads the user back to the your projects page
		JButton projectsBack = new JButton("back");
		projectsBack.setBounds(390, 580, 80, 35);
		projectsBack.setBackground(new Color(135, 145, 161));
		projectsBack.setFont(new Font("Ink Free", Font.BOLD, 20));
				
		// Add an ActionListener that leads the user back to the your projects page when the
		// button is clicked
		projectsBack.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
						
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
						
				// Link to the your projects page
				displayProjects();
						
			}
					
		});
				
		// Add the "back" JButton to the frame
		filteritApp.frame.add(projectsBack);
	}
	
	/**
	 * The following method holds the q&a for all the templates
	 */
	public static void displayQuestions() {
		
		// Set the current design of the JFrame
		filteritApp.frame.setSize(500, 670);
		filteritApp.frame.getContentPane().setBackground(new Color(14, 22, 46));
		
		// Create a q&a header JLabel
		JLabel qa = new JLabel("q&a");
		qa.setBounds(200, 20, 300, 50);
		qa.setFont(new Font("Ink Free", Font.BOLD, 40));
		qa.setForeground(new Color(157, 170, 209));
		
		JLabel subqa = new JLabel("we promise, we won't sell this info.");
		subqa.setBounds(88, 80, 300, 25);
		subqa.setFont(new Font("Ink Free", Font.PLAIN, 20));
		subqa.setForeground(Color.WHITE);
		
		JLabel note = new JLabel("note: everything you input will be added to the resume");
		note.setBounds(55, 110, 450, 20);
		note.setFont(new Font("Ink Free", Font.PLAIN, 16));
		note.setForeground(Color.WHITE);
		
		JLabel ps = new JLabel("p.s. click save when you're done");
		ps.setBounds(125, 130, 450, 20);
		ps.setFont(new Font("Ink Free", Font.PLAIN, 16));
		ps.setForeground(Color.WHITE);
		
		// Add JLabels to the frame
		filteritApp.frame.add(qa);
		filteritApp.frame.add(subqa);
		filteritApp.frame.add(note);
		filteritApp.frame.add(ps);
		
		// Declare variables
		String ln;
		
		// Create a JTextArea that stores the info from questions.txt
		JTextArea areaQ = new JTextArea(5, 20);
		areaQ.setForeground(Color.WHITE);
		areaQ.setFont(new Font("Ink Free", Font.PLAIN, 17));
		
		// Style the text in the JTextArea
		areaQ.setEditable(true);
		areaQ.setLineWrap(true);	
		areaQ.setWrapStyleWord(true);
		
		// Create a JScrollPane that holds the JTextArea
		JScrollPane sp = new JScrollPane(areaQ, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);		
		sp.setBounds(25, 170, 455, 400);
		
		// Style the JTextArea and JScrollPane
		areaQ.setBackground(new Color(14, 22, 46));
		sp.setBorder(BorderFactory.createEmptyBorder());
		
		// Add the JScrollPane to the frame
		filteritApp.frame.add(sp);
		
		// Read data from questions.txt and add it to the JTextArea
		try {
			BufferedReader input = new BufferedReader(new FileReader(qFile));
			
//			int num = 0;
//			String line1 = Files.readAllLines(Paths.get(qFile)).get(1);
			
			// Read in each line while the questions.txt file is empty and add
			// each one to the JTextArea
			while ((ln = input.readLine()) != null) {
				areaQ.read(input, "areaQ");
				
//				if (num % 2 != 0) {
//					ln = input.readLine();
//				}
//				
//				if (num % 2 == 0) {
//					areaQ.setEditable(false);
//				}
//				++num;
//				if (num % 2 != 0) {
//					areaQ.setEditable(true);
//				}
				
//				String line1 = Files.readAllLines(Paths.get(qFile)).get(1);
//				System.out.println(line1);
				
			}
			
//			int num = 0;
//			String fileLn;
//			while ((fileLn = input.readLine()) != null) {
//				if (num % 2 == 0) {
//					System.out.println("1");
//					areaQ.setEditable(false);
//				}
//				++num;
//			}
			
//			int num = areaQ.getCaretPosition();
//			try {
//				int lineNum = areaQ.getLineOfOffset(num);
//				if (lineNum == 1) {
//					areaQ.setEditable(false);
//				}
//			} catch (BadLocationException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
			
			// Control the number of lines per response 
//			int lnLimit = areaQ.getLineCount();
//			System.out.println(lnLimit);
			
		}
		
		// Else, print an error message to the console regarding the reading of the file
		catch(IOException iox) {
			System.out.println("Problem reading " + qFile);
		}
		
		// Add a "save" JButton that saves the info in the JTextArea to a .txt file
		JButton save = new JButton("save");
		save.setBounds(15, 590, 80, 35);
		save.setBackground(new Color(135, 145, 161));
		save.setFont(new Font("Ink Free", Font.BOLD, 20));
		
		// Add an ActionListener that saves the user's info
		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// When info is added to the JTextArea, try saving it to a .txt file
				try {
					BufferedWriter writer2 = new BufferedWriter(new FileWriter(aFile, false));
					areaQ.write(writer2);
					
					// Isolate the lines in answers.txt which contain the questions
					
					// Declare strings for the 9 questions within the .txt file
					String ln1 = "1. What is your full name?";
					String ln2 = "2. What is your title/current occupation (i.e. secondary student)?";
					String ln3 = "3. Tell us about yourself. Who are you? What job are you interested in? (2-3 sentences)";
					String ln4 = "4. What are your skills (i.e. time management | resourceful | organized)?";
					String ln5 = "5. What education have you received and where (i.e. elementary/middle/high school, university/college)?";
					String ln6 = "6. What volunteer or work experience do you have? Explain in point form some of the skills you gained and tasks you completed.";
					String ln7 = "7. Do you have any relevant certifications or achievements? If so, list them.";
					String ln8 = "8. List your references (name, position, email).";
					
					// Declare a string that holds the position of the current line being 
					// read by the BufferedReader
					String lnCurrent;
					
					// Declare a BR and BW to read the current answers file and remove
					// the questions from the new file
					BufferedReader br = new BufferedReader(new FileReader(aFile));
					BufferedWriter bw = new BufferedWriter(new FileWriter(aeFile, false));
					
					// Read the lines in the answers.txt file to check for the questions
					while ((lnCurrent = br.readLine()) != null) {
						String lnTrim = lnCurrent.trim(); // remove whitespace from current line
						
						// If, the current line is the same as any of the question strings,
						// re-initialize the string to be empty
						if(lnTrim.equals(ln1) || lnTrim.equals(ln2) || lnTrim.equals(ln3) || lnTrim.equals(ln4) || 
								lnTrim.equals(ln5) || lnTrim.equals(ln6) || lnTrim.equals(ln7) || lnTrim.equals(ln8)) {
							lnCurrent = "";
						}
						
						// In the answersedit.txt file, write only the answers with a line
						// separator between each answer
						bw.write(lnCurrent + System.getProperty("line.separator"));
					}
					
					// Close both the BR and BW
					br.close();
					bw.close();
				}
				
				// Else, catch the exception and print an error message
				catch(IOException iox) {
					System.out.println("Error, please try again.");
				}
				
			}
			
		});
		
		// Isolate the lines in answers.txt which contain the questions
//				try {
//					String line0 = Files.readAllLines(Paths.get(aFile)).get(0);
//					System.out.println(line0);
//					
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
		
		// Add the "save" JButton to the frame
		filteritApp.frame.add(save);
		
		// Add a "next" JButton that leads the user back to the your projects page
		JButton next = new JButton("next");
		next.setBounds(390, 590, 80, 35);
		next.setBackground(new Color(135, 145, 161));
		next.setFont(new Font("Ink Free", Font.BOLD, 20));
		
		// Add an ActionListener that leads the user to their actual resume on click
		next.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
						
				// Link to the actual formal resume page
				displayFormal();
				
			}
			
		});
		
		// Add the "next" JButton to the frame
		filteritApp.frame.add(next);
		
		// Control the number of lines per response 
//		final int LIMIT = 100;
//		int lnLimit = areaQ.getLineCount() - LIMIT;
//		
//		if (lnLimit > 0) {
//			try {
//				int lastLnPos = areaQ.getLineEndOffset(lnLimit - 1);
//				areaQ.replaceRange("", 0, lastLnPos);
//			}
//			catch (Exception x) {
//				x.printStackTrace();
//			}
//		}
		
	}
	
	/**
	 * The following method displays the formal resume template with the user's info
	 */
	public static void displayFormal() {
		
		// Set the current design of the JFrame
		filteritApp.frame.setSize(500, 670);
		filteritApp.frame.getContentPane().setBackground(new Color(14, 22, 46));
		
		// Create a q&a header JLabel
		resume.setBounds(130, 20, 300, 50);
		resume.setFont(new Font("Ink Free", Font.BOLD, 40));
		resume.setForeground(new Color(157, 170, 209));
		
		// Add the resume header JLabel to the frame
		filteritApp.frame.add(resume);
		
		// Create JComboBoxes for the different customizations within the resume
		
		// JComboBox for fonts
		String[] fonts = {"fonts", "arial", "times", "ink free", "bahnschrift", "calibri"};
		JComboBox<String> fontOptions = new JComboBox<String>(fonts);
		fontOptions.setBounds(20, 90, 120, 30);
		fontOptions.setBackground(new Color(171, 180, 204));
		fontOptions.setFont(new Font("Ink Free", Font.PLAIN, 17));
		
		// JComboBox for backgrounds
		String[] backgrounds = {"backgrounds","white", "black", "navy blue", "light blue", "beige"};
		JComboBox<String> bkgOptions = new JComboBox<String>(backgrounds);
		bkgOptions.setBounds(160, 90, 140, 30);
		bkgOptions.setBackground(new Color(171, 180, 204));
		bkgOptions.setFont(new Font("Ink Free", Font.PLAIN, 17));
		
		// JComboBox for font colours
		String[] fontColours = {"font colours", "white", "black", "navy blue"};
		JComboBox<String> colourOptions = new JComboBox<String>(fontColours);
		colourOptions.setBounds(325, 90, 140, 30);
		colourOptions.setBackground(new Color(171, 180, 204));
		colourOptions.setFont(new Font("Ink Free", Font.PLAIN, 17));
		
		// Add JComboBoxes to the frame
		filteritApp.frame.add(fontOptions);
		filteritApp.frame.add(bkgOptions);
		filteritApp.frame.add(colourOptions);
		
		// Revalidate and repaint the frame to add new components
		filteritApp.frame.revalidate();
		filteritApp.frame.repaint();
		
//		fontOptions.setSelectedIndex(0);
		
//		JPanel p = new JPanel();
//		JScrollPane jsp = new JScrollPane(p, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
//		jsp.setBounds(20, 170, 455, 400);
		
//		JTextArea p = new JTextArea(5, 20);
//		JScrollPane jsp = new JScrollPane(p, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		jsp.setBounds(10, 150, 470, 420);
		
		p.setEditable(false);
		p.setLineWrap(true);
		p.setWrapStyleWord(true);
		
//		p.setBackground(new Color(14, 22, 46));
		p.setBackground(new Color(87, 145, 135));
		jsp.setBorder(BorderFactory.createEmptyBorder());
		
//		jsp.setBounds(10, 150, 470, 420);
		filteritApp.frame.add(jsp);
		
		// Try reading specific lines from answersedit.txt and adding them to the
		// appropriate JTextArea
		try {
			
			// Declare variables for the lines that will contain the user's resume data
			
			String line1 = Files.readAllLines(Paths.get(aeFile)).get(1); // for name
			String line3 = Files.readAllLines(Paths.get(aeFile)).get(3); // for title
			String line5 = Files.readAllLines(Paths.get(aeFile)).get(5); // for about info
			String line7 = Files.readAllLines(Paths.get(aeFile)).get(7); // for skills
			
			// for user's education
			String line9 = Files.readAllLines(Paths.get(aeFile)).get(9);
			String line10 = Files.readAllLines(Paths.get(aeFile)).get(10);
			String line11 = Files.readAllLines(Paths.get(aeFile)).get(11);
			
			// for user's volunteer/work experience
			String line13 = Files.readAllLines(Paths.get(aeFile)).get(13);
			String line14 = Files.readAllLines(Paths.get(aeFile)).get(14);
			String line15 = Files.readAllLines(Paths.get(aeFile)).get(15);
			String line16 = Files.readAllLines(Paths.get(aeFile)).get(16);
			String line17 = Files.readAllLines(Paths.get(aeFile)).get(17);
			
			
			// Add the JTextAreas to the frame
			
			// for user's full name
			area.displayTextAreas(line1, 15, 10, 445, 40, 30, p);
			// 140
//			filteritApp.frame.revalidate();
//			filteritApp.frame.repaint();
			
			// for user's title/occupation
			area.displayTextAreas(line3, 15, 50, 445, 30, 20, p);
			//180
			
//			filteritApp.frame.revalidate();
//			filteritApp.frame.repaint();
			// for user's about/job info
			area.displayTextAreas(line5, 15, 87, 445, 105, 17, p);
			
			// for user's top skills
			area.displayTextAreas("TOP SKILLS \n" + line7, 15, 164, 445, 60, 17, p);
		
			// for user's education
			area.displayTextAreas("EDUCATION \n" + line9 + "\n" + line10 + "\n" + line11, 15, 216, 445, 105, 17, p);
	
			// for user's volunteer/work experience
			area.displayTextAreas("VOLUNTEER/WORK EXPERIENCE \n" + line13 + "\n" + line14 + "\n" + line15 + "\n" + line16 + "\n" + line17, 15, 320, 445, 145, 17, p);
		} 
		
		// If the data cannot be read, print an error message to the console
		catch(IOException iox) {
			System.out.println("Error, please try again.");
		}
		
		filteritApp.frame.revalidate();
		filteritApp.frame.repaint();
		
		// Create a "back" JButton that leads the user to the q&a page to change responses
		JButton qaBack = new JButton("back");
		qaBack.setBounds(15, 585, 80, 35);
		qaBack.setBackground(new Color(135, 145, 161));
		qaBack.setFont(new Font("Ink Free", Font.BOLD, 20));
						
		// Add an ActionListener that leads the user back to the your projects page when the
		// button is clicked
		qaBack.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
								
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
								
				// Link to the your projects page
				displayQuestions();
								
			}
							
		});
						
		// Add the "back" JButton to the frame
		filteritApp.frame.add(qaBack);
		
		// Create a preview JButton for when the user is finished their resume
		preview.setBounds(360, 585, 110, 35);
		preview.setBackground(new Color(135, 145, 161));
		preview.setFont(new Font("Ink Free", Font.BOLD, 20));
		
		// Add an ActionListener that leads the user to the preview of the resume on click
		preview.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// Clear and repaint the frame
				filteritApp.frame.getContentPane().removeAll();
				filteritApp.frame.repaint();
				
				// Link to the preview page
				
			}
			
		});
		
		// Add the preview JButton to the frame
		filteritApp.frame.add(preview);
	}
	
	/**
	 * The following method is for the JTextAreas that display the user's data in
	 * the displayFormal() method
	 * @param line
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param fontSize
	 * @param frame
	 */
	public void displayTextAreas(String line, int x, int y, int w, int h, int fontSize, JTextArea panel) {
		
		JTextArea taName = new JTextArea(line);
		taName.setBounds(x, y, w, h);
		taName.setFont(new Font("Ink Free", Font.PLAIN, fontSize));
		taName.setForeground(Color.WHITE);
		taName.setOpaque(false);
		taName.setEditable(false);
		taName.setLineWrap(true);	
		taName.setWrapStyleWord(true);
		p.add(taName);
//		filteritApp.frame.add(taName);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
//			areaQ.setEditable(false);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	} 
}